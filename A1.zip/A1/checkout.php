<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="UTF-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Document</title>
  <script src="script.js"></script>

  <link rel="stylesheet" href="styles.css" />
  <link href="https://fonts.googleapis.com/css2?family=Raleway:wght@700&family=Oleo+Script:wght@700&family=Quicksand:wght@300;500;700&display=swap" rel="stylesheet" />
</head>

<body>
  <main>
    <a href="index.php">home</a>
    <div id="content">
      <table id="checkout">
        <form action="sendEmail.php" method="post">
          <tr>
            <td>
              <h1 id="page-title"> Checkout</h1>
            </td>
          </tr>
          <tr>
            <td><input type="text" id="name" name="name" required placeholder="Name"></td>
          </tr>
          <tr>
            <td><input type="email" id="email" name="email" required placeholder="Email"></td>
          </tr>

          <tr>
            <td><input type="text" id="street" name="street" required placeholder="Street Address"></td>
          </tr>
          <tr>
            <td><input type="text" id="suburb" name="suburb" required placeholder="Suburb"></td>
          </tr>
          <tr>
            <td><input type="text" id="state" name="state" required placeholder="State"></td>
          </tr>
          <tr>
            <td><input type="text" id="country" name="country" required placeholder="Country"></td>
          </tr>
          <tr>
            <td> <input id="submit" type="submit" value="Place Order "> </td>
          </tr>
        </form>
      </table>
      <?php
      include 'establish_connection.php';
      session_start();
        $totalPrice = 0;
        $_SESSION['totalPrice'] = 0;
        echo '<ul id="cartDisplayCheckout" >';
        foreach ($_SESSION['cart'] as $item) {
          $_SESSION['totalPrice'] += $item['unit_price'] * $item['quantity'];
          echo '<li id="cartItem">
          <div>
            <img id="cartImg"src="/A1/images/' . $item['product_name'] . '.png" alt=""> 
            <div id="info">
              <div>
                <h2 id="cartHeader">' . $item['quantity'] . ' x '  . $item['product_name'] . '  $' . $item['unit_price'] . '</h2> 
              </div>
            </div>
          </div>  
        </li>';
        }
        echo '<h2> Total Price: $' . $_SESSION['totalPrice'] . '</h2>';
      ?>
      </ul>
    </div>
</body>

</html>

<script>

</script>